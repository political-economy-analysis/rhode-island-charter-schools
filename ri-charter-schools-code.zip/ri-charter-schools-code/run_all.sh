#!/usr/bin/env bash
# Rebuilds every table, figure and the memo from public data. Run from this folder: bash run_all.sh
# Downloads are cached in data/raw/ and reused; delete a cached file to force a fresh download.
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p data/raw data/processed figures/memo
py="${PYTHON:-python3}"
for s in 01_charter_locations_enrollment 03_add_finance 05_add_private_schools 06_fetch_outcomes 07_build_master_school_list; do
  echo "== $s"; $py scripts/$s.py
done
for s in 08_sector_comparison_chart 09_proficiency_vs_poverty 11_proficiency_vs_poverty_centroids 02_map_charter_schools; do
  echo "== $s"; $py scripts/$s.py
done
echo "== 13_memo_statistics"; $py scripts/13_memo_statistics.py
for s in 02_map_charter_schools 08_sector_comparison_chart 11_proficiency_vs_poverty_centroids; do
  echo "== $s --memo"; $py scripts/$s.py --memo
done
echo "== 14_build_memo"; $py scripts/14_build_memo.py
# Not used in the memo: interactive map and two chart variants.
if [ "${WITH_EXTRAS:-0}" = "1" ]; then
  for s in 04_build_interactive_map 10_proficiency_vs_poverty_charter_fit 12_proficiency_vs_poverty_spokes; do
    echo "== $s"; $py scripts/$s.py
  done
fi
echo "Done: memo.pdf, memo.docx, figures/, data/processed/"
