# Rhode Island charter schools: code base for the Debate #3 memo

Code, data and instructions behind the memo *Lifting the charter moratorium and doubling the cap from 28 to 56*
(`memo.pdf`, `memo.docx`). Every number and exhibit in the memo is produced by a script in `scripts/`.
No API keys, passwords or accounts are needed; all data are public.

Interactive map (optional extra): https://political-economy-analysis.github.io/ri-charter-schools-map/
Source repository: https://github.com/political-economy-analysis/rhode-island-charter-schools

## Quick start

```bash
pip install -r requirements.txt
bash run_all.sh            # a few minutes; downloads the private-school file (about 45 MB) the first time
```

Run from this folder (paths are relative to it). The script rebuilds `data/processed/`, `figures/`, `memo.pdf` and
`memo.docx`. It prints `memo word count: ... ` (the memo must stay at or under 1,000 words; the appendix and references
do not count). Set `WITH_EXTRAS=1` to also build the interactive map and two chart variants not used in the memo.

Checked by rerunning from a fresh copy, both with the bundled `data/raw/` cache and with the cache deleted (all
data downloaded anew): all 19 CSVs in `data/processed/` matched the originals byte for byte, and the memo came to 873 words.

Tested with Python 3.9 (pandas 2.3, numpy 2.0, matplotlib 3.9, pyshp 3.1, pillow 11, fonttools 4.60, reportlab 5.0,
python-docx). Needs an internet connection only for data that is not already in `data/raw/`.

## What is in this folder

| Path | Contents |
|---|---|
| `scripts/` | The pipeline, numbered in run order (table below), plus `style.py` (shared fonts and colors) and `map_template.html` |
| `data/raw/` | Cached downloads (Urban Institute API JSON), the Census town shapefile, and the Rhode Island flag emblem |
| `data/processed/` | Tidy CSVs produced by the scripts (included so results can be compared without rerunning) |
| `figures/` | Exhibit images (`figures/memo/` holds the three used in the memo) and the interactive map HTML |
| `memo.pdf`, `memo.docx` | The memo, technical appendix and references, as built by `scripts/14_build_memo.py` |
| `run_all.sh`, `requirements.txt` | Run order and dependencies |

## Scripts and run order

`run_all.sh` runs them in this order (the same order is given in Appendix A of the memo).

| Script | Purpose | Main output |
|---|---|---|
| `01_charter_locations_enrollment.py` | Charter school list (CCD directory, 2024) | `ri_charter_schools_2024.csv` |
| `03_add_finance.py` | Adds district finance (FY2020) | `ri_charter_schools_2024_enriched.csv`, `ri_noncharter_schools_2024_enriched.csv` |
| `05_add_private_schools.py` | Private schools (NCES Private School Survey 2021-22) | `ri_private_schools_2021.csv` |
| `06_fetch_outcomes.py` | Test scores, graduation rates, enrollment by race | `ri_edfacts_*.csv`, `ri_ccd_enrollment_by_race.csv` |
| `07_build_master_school_list.py` | Master list: charter, traditional public, private | `ri_school_master_list.csv` |
| `08_sector_comparison_chart.py` | Exhibit 1 (sector comparison) | `sector_comparison_*.csv`, `figures/memo/exhibit1_*.png` |
| `09_proficiency_vs_poverty.py` | School-level scores and poverty, 2018-19 | `proficiency_vs_poverty_schools.csv` |
| `11_proficiency_vs_poverty_centroids.py` | Exhibit 2 (scores against poverty) | `figures/memo/exhibit2_*.png` |
| `02_map_charter_schools.py` | Exhibit 3 (charter map) | `figures/memo/exhibit3_*.png` |
| `13_memo_statistics.py` | Other statistics quoted in the memo | `memo_statistics_*.csv` |
| `02`, `08`, `11` with `--memo` | Memo versions of the exhibits (no in-figure title or logo) | `figures/memo/` |
| `14_build_memo.py` | Builds the memo and technical appendix | `memo.pdf`, `memo.docx` |
| `04`, `10`, `12` (optional) | Interactive map; chart variants | `figures/ri_charter_map.html`, `figures/proficiency_vs_poverty_*.png` |

## Data sources

All downloads are cached in `data/raw/` and reused; delete a cached file to force a fresh download. The scripts fetch
anything missing, so the cache could be removed entirely.

| Source | Used for | Where |
|---|---|---|
| Urban Institute Education Data Portal, NCES Common Core of Data | School directory (2018, 2020, 2024), enrollment by race, district finance (2020) | `https://educationdata.urban.org/api/v1/` (scripts 01, 03, 06, 09, 11) |
| Urban Institute Education Data Portal, EDFacts | Math and reading proficiency by school, grade, race, special population | same API (script 06) |
| NCES Private School Universe Survey 2021-22 | Private school enrollment and demographics | `https://nces.ed.gov/surveys/pss/zip/pss2122_pu_csv.zip` (script 05 downloads and unzips it to `data/raw/pss/`, about 45 MB) |
| Census cartographic boundary file, 2022 county subdivisions | Town outlines for maps | `cb_2022_44_cousub_500k` is bundled in `data/raw/ri_cousub/`; original at `https://www.census.gov/geographies/mapping-files/time-series/geo/cartographic-boundary.html` |
| Flag of Rhode Island (public domain) | Emblem on the memo and figures | Wikimedia Commons, bundled as `data/raw/logo/flag.png` |

## Conventions worth knowing

- **Years.** The Urban portal's year is read as the start of the school year (2018 = 2018-19, 2024 = 2024-25). This is an
  inference from the portal's conventions and should be confirmed.
- **Proficiency** is published as a range; all results use the midpoint. API codes -1 (missing), -2 (not applicable) and
  -3 (suppressed) are dropped.
- **Low-income** means eligible for free or reduced-price lunch divided by enrollment.
- **Charter** follows the CCD charter flag. The memo's 24 charters are operators running the 42 sites in the data.
- Full methods, definitions and limitations are in the technical appendix of `memo.pdf`.

## Notes

- **Font.** The memo and figures use Charter, which ships with macOS. On other systems the scripts fall back to DejaVu Sans
  (bundled with matplotlib), so layout and page breaks may differ slightly from the supplied PDF.
- **Live data.** The Urban API and NCES files are live sources. If they are revised, a fresh download could differ slightly
  from the bundled cache; the cache in `data/raw/` is the exact input used for the memo.
- **Interactive map.** `figures/ri_charter_map.html` loads Leaflet from a public CDN, so viewing it needs an internet connection.
